<?php

namespace Illuminate\Database\Events;

class MigrationEnded extends MigrationEvent
{
    //
}
